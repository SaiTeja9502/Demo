package com.capgemini.pecuniabank.passbookmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import com.capgemini.pecuniabank.passbookmanagement.dto.TransactionDto;
import com.capgemini.pecuniabank.passbookmanagement.exceptions.EnterValidAccountException;
public interface PecuniaBankSystemService 
{
	public List<TransactionDto> passBookUpdate(Long accNo) throws EnterValidAccountException;
	public List<TransactionDto> accountSummary(Long s1, String d, String e) throws EnterValidAccountException;
}
















/*
LoginDto  l = null;
loginService d = null;
String name = null;
String password = null;
@Before
public void setUp()
{
	 l = new LoginDto();
	 d = new LoginServiceImpl();
}
@After

@Test
public void testAddPositive()
{
	boolean ret = d.verifyUser(name,password);
	assertEquals(true,ret);
}

*/