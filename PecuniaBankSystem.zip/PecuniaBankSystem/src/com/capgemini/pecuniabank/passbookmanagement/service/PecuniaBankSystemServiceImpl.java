package com.capgemini.pecuniabank.passbookmanagement.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capgemini.pecuniabank.passbook.managementutil.ConvertDate;
import com.capgemini.pecuniabank.passbookmanagement.dao.PecuniaBankSystemDao;
import com.capgemini.pecuniabank.passbookmanagement.dao.PecuniaBankSystemDaoImpl;
import com.capgemini.pecuniabank.passbookmanagement.dto.TransactionDto;
import com.capgemini.pecuniabank.passbookmanagement.exceptions.EnterValidAccountException;

public class PecuniaBankSystemServiceImpl implements PecuniaBankSystemService
{
	PecuniaBankSystemDao pec = new PecuniaBankSystemDaoImpl();
	public List<TransactionDto> passBookUpdate(Long accNo) throws EnterValidAccountException
	{
		List<TransactionDto> arr = new ArrayList<>();
		if(accNo>0)
		 arr=pec.passBookUpdate(accNo);
		else
			throw new EnterValidAccountException();
		return arr;	
	}
	public List<TransactionDto> accountSummary(Long s1, String d, String e) throws EnterValidAccountException
	{
		List<TransactionDto> arr = new ArrayList<>();
		if(s1>0)
		{
		Date start = ConvertDate.convertDate(d);
		Date end = ConvertDate.convertDate(e);
		arr = pec.accountSummary(s1,start,end);
		}
		else
			throw new EnterValidAccountException();
		return arr;
}}
