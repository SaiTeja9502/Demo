package com.capgemini.pecuniabank.passbookmanagement.dto;
import java.util.Date;

public class TransactionDto 
{
	private long transId;
	private long accountId;
	private String type;
	private double amount;
	private Date dateoftrans;
	private long transfrom;
	public TransactionDto() {
		super();
	}
	public TransactionDto(long transId, long accountId, String type, double amount, Date dateoftrans,long transfrom) {
		super();
		this.transId = transId;
		this.accountId = accountId;
		this.type = type;
		this.amount = amount;
		this.dateoftrans = dateoftrans;
		this.transfrom = transfrom;
	}
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Date getDateoftrans() {
		return dateoftrans;
	}
	public void setDateoftrans(Date dateoftrans) {
		this.dateoftrans = dateoftrans;
	}
	public long getTransfrom() {
		return transfrom;
	}
	public void setTransfrom(long transfrom) {
		this.transfrom = transfrom;
	}
	}


