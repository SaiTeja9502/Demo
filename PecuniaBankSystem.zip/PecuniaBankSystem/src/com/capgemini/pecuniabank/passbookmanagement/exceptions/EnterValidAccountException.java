package com.capgemini.pecuniabank.passbookmanagement.exceptions;

public class EnterValidAccountException extends Exception
{
	public String getMessage()
	{
		return "Account number must be positive";
	}
}
