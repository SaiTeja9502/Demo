package com.capgemini.pecuniabank.passbookmanagement.testing;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.pecuniabank.passbookmanagement.dao.PecuniaBankSystemDao;
import com.capgemini.pecuniabank.passbookmanagement.dao.PecuniaBankSystemDaoImpl;
import com.capgemini.pecuniabank.passbookmanagement.dto.TransactionDto;
import com.capgemini.pecuniabank.passbookmanagement.exceptions.EnterValidAccountException;


public class JunitTestCase
{
	PecuniaBankSystemDao pec = null;
	int a = 0;
	@Before
	public void setUp()
	{
		pec = new PecuniaBankSystemDaoImpl();
	}
	@After
	public void tearDown()
	{
		pec = null;
	}
	@Test
	public void testPositiveCase() 
	{
		List<TransactionDto> arr = new ArrayList();
		arr = pec.passBookUpdate(10000L);
		if(arr.size()>0)
			a=1;
		Assert.assertEquals(a,1);
	}
	@Test
	public void testNegativeCase() 
	{
		List<TransactionDto> arr = new ArrayList();
		arr = pec.passBookUpdate(1000L);
		if(arr.size()>0)
			a=1;
		Assert.assertNotEquals(1,a);
	}

}

