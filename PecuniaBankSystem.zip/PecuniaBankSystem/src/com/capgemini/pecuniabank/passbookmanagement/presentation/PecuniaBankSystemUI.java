package com.capgemini.pecuniabank.passbookmanagement.presentation;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.capgemini.pecuniabank.passbook.managementutil.ConvertDate;
import com.capgemini.pecuniabank.passbookmanagement.dto.TransactionDto;
import com.capgemini.pecuniabank.passbookmanagement.exceptions.EnterValidAccountException;
import com.capgemini.pecuniabank.passbookmanagement.service.PecuniaBankSystemServiceImpl;
import com.capgemini.pecuniabank.passbookmanagement.service.PecuniaBankSystemService;
public class PecuniaBankSystemUI
{	
	public static void main(String[] args) 
	{
		List<TransactionDto> arr = new ArrayList();
		TransactionDto d = new TransactionDto();
		PecuniaBankSystemService pec = new PecuniaBankSystemServiceImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose the Passbook Maintenance:");
		System.out.println("1. Passbook Update");
		System.out.println("2. Account Summary");
		int n = sc.nextInt();
		switch(n)
		{
		case 1:
			System.out.println("Enter the account number");
			Long s = sc.nextLong();
			try 
			{
				arr = pec.passBookUpdate(s);
				System.out.println("Trans_id  Acc_id  Type Amount  TransDate  TransFrom");
				for(TransactionDto dt : arr)
				{
					System.out.println("  "+dt.getTransId()+"   "+dt.getAccountId()+"    "+dt.getType()+"   "+dt.getAmount()+" "+dt.getDateoftrans()+"    "+dt.getTransfrom());	
				}
			}
			catch (EnterValidAccountException e1) 
			{
				System.out.println(e1.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter the account number");
			Long s1 = sc.nextLong();
			sc.nextLine();
			System.out.println("Enter the Start Date");
			String da = sc.nextLine();
			System.out.println("Enter the End Date");
			String e = sc.nextLine();
			try 
			{
				arr = pec.accountSummary(s1,da,e);
				System.out.println("Trans_id  Acc_id  Type Amount  TransDate  TransFrom");
				for(TransactionDto dt : arr)
				{
					System.out.println("  "+dt.getTransId()+"   "+dt.getAccountId()+"    "+dt.getType()+"   "+dt.getAmount()+"  "+dt.getDateoftrans()+"    "+dt.getTransfrom());	
				}
			}
			catch (EnterValidAccountException e1) 
			{
				System.out.println(e1.getMessage());
			}
			break;
		default:
			System.out.println("Invalid Option");
		}
	}

}
