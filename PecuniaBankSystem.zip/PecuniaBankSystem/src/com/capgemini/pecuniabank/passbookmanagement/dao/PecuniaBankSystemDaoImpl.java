package com.capgemini.pecuniabank.passbookmanagement.dao;

import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.pecuniabank.passbook.managementutil.ConvertDate;
import com.capgemini.pecuniabank.passbook.managementutil.TransactionQueries;
import com.capgemini.pecuniabank.passbookmanagement.dto.TransactionDto;

public class PecuniaBankSystemDaoImpl implements PecuniaBankSystemDao
{
	private Connection connection = null;
	private PreparedStatement pst;
	private ResultSet result;
	@Override
	public void openConnection() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@Localhost:1521:xe";
			connection = DriverManager.getConnection(url,"Tej007","saiteja");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void closeConnection() {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<TransactionDto> passBookUpdate(Long accNo)
	{
		openConnection();
		
		List<TransactionDto> arr = new ArrayList<>(); 
		try
		{
			pst = connection.prepareStatement(TransactionQueries.transQuery);
			pst.setLong(1, accNo);
			pst.executeUpdate();
			result = pst.executeQuery();
			while(result.next())
			{
				TransactionDto dto = new TransactionDto();
				dto.setTransId(result.getLong(1));
				dto.setAccountId(result.getLong(2));
				dto.setType(result.getString(3));
				dto.setAmount(result.getDouble(4));
				dto.setDateoftrans(result.getDate(5));
				dto.setTransfrom(result.getLong(6));
				arr.add(dto);
			}
			result.close();
			pst.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return arr;
	}

	@Override
	public List<TransactionDto> accountSummary(Long accNo, Date startDate, Date endDate) 
	{
		openConnection();
		List<TransactionDto> arr = new ArrayList<>();
		try
		{
			pst = connection.prepareStatement(TransactionQueries.transQuery);
			pst.setLong(1, accNo);
			result = pst.executeQuery();
			while(result.next())
			{
				java.sql.Date sqldate = result.getDate(5);
				Date d = new Date(sqldate.getTime());
				if(d.compareTo(startDate)>0&&d.compareTo(endDate)<0)
				{
					TransactionDto dto = new TransactionDto();
					dto.setTransId(result.getLong(1));
					dto.setAccountId(result.getLong(2));
					dto.setType(result.getString(3));
					dto.setAmount(result.getDouble(4));
					dto.setDateoftrans(result.getDate(5));
					dto.setTransfrom(result.getLong(6));
					arr.add(dto);
				}
			}
			result.close();
			pst.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return arr;
	}

}
