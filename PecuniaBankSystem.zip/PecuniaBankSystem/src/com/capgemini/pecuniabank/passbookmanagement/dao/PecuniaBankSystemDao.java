package com.capgemini.pecuniabank.passbookmanagement.dao;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public interface PecuniaBankSystemDao 
{
	public void openConnection();
	public void closeConnection();
	public List passBookUpdate(Long accNo);
	public List accountSummary(Long accNo,Date startDate,Date endDate);
}
