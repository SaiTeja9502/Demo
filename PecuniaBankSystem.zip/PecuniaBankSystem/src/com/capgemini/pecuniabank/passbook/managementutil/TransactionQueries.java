package com.capgemini.pecuniabank.passbook.managementutil;

public class TransactionQueries 
{
	public static String transQuery = "select * from transaction where account_id=?";
}
