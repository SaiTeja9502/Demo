package com.cg.anurag.pbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PecuniaBankSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PecuniaBankSystemApplication.class, args);
	}

}
